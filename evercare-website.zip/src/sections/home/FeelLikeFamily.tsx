/**
 * FeelLikeFamily.tsx
 *
 * This section ("Care that feels like family") was intentionally removed
 * as part of homepage simplification. It now returns null
 * to preserve import paths and prevent build errors.
 */

import React from "react";

export default function FeelLikeFamily() {
  return null;
}
