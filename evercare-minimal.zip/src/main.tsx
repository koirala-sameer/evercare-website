import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

// Global styles
import "./styles/evercare-theme.css";
import "./index.css";

// Side-effect import safely mounts the Floating CTA in the browser
import "./mountFloatingCTA";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
